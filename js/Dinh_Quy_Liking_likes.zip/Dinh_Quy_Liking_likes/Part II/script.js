var num1postlike = 9;
var countElement = document.querySelector("#num1postlike")

console.log(countElement);

function addlike() {
    num1postlike++;
    countElement.innerText = num1postlike + " like(s)";
    console.log(num1postlike);
}

var num2postlike = 12;
var countElement2 = document.querySelector("#num2postlike")

console.log(countElement2);

function addlike2() {
    num2postlike++;
    countElement2.innerText = num2postlike + " like(s)";
    console.log(num2postlike);
}

var num3postlike = 9;
var countElement3 = document.querySelector("#num3postlike")

console.log(countElement3);

function addlike3() {
    num3postlike++;
    countElement3.innerText = num3postlike + " like(s)";
    console.log(num3postlike);
}