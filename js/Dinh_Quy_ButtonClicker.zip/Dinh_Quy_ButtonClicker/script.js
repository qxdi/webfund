function disappear(element) {
    element.remove()
}
function logout(element) {
    element.innerText = "Logout";
}
function alertclick() {
    alert("Ninja was liked")
}